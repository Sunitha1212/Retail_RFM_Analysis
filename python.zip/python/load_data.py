import pandas as pd
import sqlite3
import os

BASE_DIR = os.path.dirname(__file__)
db_path = os.path.join(BASE_DIR, "retail.db")

conn = sqlite3.connect(db_path)

pd.read_csv("../data/dim_customers.csv").to_sql(
    "dim_customers", conn, if_exists="append", index=False
)

pd.read_csv("../data/dim_products.csv").to_sql(
    "dim_products", conn, if_exists="append", index=False
)

pd.read_csv("../data/fact_sales.csv").to_sql(
    "fact_sales", conn, if_exists="append", index=False
)

conn.close()
print("Data loaded successfully")
