import sqlite3
import pandas as pd

# 1. Connect to SQLite
conn = sqlite3.connect(
    r"C:\Users\anush\Desktop\Retail_RFM_Project\python\retail.db"
)

# 2. Load joined data
query = """
SELECT
    f.customer_id,
    f.sales_date,
    f.quantity,
    p.price
FROM fact_sales f
JOIN dim_products p
    ON f.product_id = p.product_id
"""

df = pd.read_sql(query, conn)
conn.close()

print("Rows loaded:", len(df))

# 🔴 SAFETY CHECK
if df.empty:
    print("❌ No data found. Please check database and data loading.")
    exit()

# 3. Fix data types
df["sales_date"] = pd.to_datetime(df["sales_date"], errors="coerce")
df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
df["price"] = pd.to_numeric(df["price"], errors="coerce")

# 4. Remove invalid rows
df = df.dropna(subset=["customer_id", "sales_date"])

# 5. Calculate monetary value
df["Sales_Value"] = df["quantity"] * df["price"]

# 6. Snapshot date
snapshot_date = df["sales_date"].max() + pd.Timedelta(days=1)

# 7. RFM Calculation (CORRECT)
rfm = (
    df.groupby("customer_id")
      .agg(
          Recency=("sales_date", lambda x: (snapshot_date - x.max()).days),
          Frequency=("sales_date", "count"),
          Monetary=("Sales_Value", "sum")
      )
      .reset_index()
)

# 8. Customer Segmentation
def segment_customer(row):
    if row["Monetary"] >= 5000 and row["Frequency"] >= 10:
        return "Champions"
    elif row["Frequency"] >= 5:
        return "Loyal Customers"
    elif row["Recency"] <= 30:
        return "Potential Customers"
    else:
        return "At Risk Customers"

rfm["Customer_Segment"] = rfm.apply(segment_customer, axis=1)

# 9. Export CSV
output_path = r"C:\Users\anush\Desktop\Retail_RFM_Project\data\RFM_output.csv"
rfm.to_csv(output_path, index=False)

print("✅ RFM automation completed successfully!")
print("📁 Output saved at:", output_path)
