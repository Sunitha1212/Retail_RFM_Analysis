
-- Total Revenue
SELECT 
    SUM(total_amount) AS total_revenue
FROM fact_sales;

-- Total Orders
SELECT 
    COUNT(DISTINCT sales_id) AS total_orders
FROM fact_sales;

-- Total Quantity Sold
SELECT 
    SUM(quantity) AS total_units_sold
FROM fact_sales;

-- Average Order Value
SELECT 
    AVG(total_amount) AS avg_order_value
FROM fact_sales;

-- Revenue by Product
SELECT 
    p.product_name,
    SUM(f.total_amount) AS product_revenue
FROM fact_sales f
JOIN dim_products p 
ON f.product_id = p.product_id
GROUP BY p.product_name
ORDER BY product_revenue DESC;

-- Revenue by Category
SELECT 
    p.category,
    SUM(f.total_amount) AS category_revenue
FROM fact_sales f
JOIN dim_products p 
ON f.product_id = p.product_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- Top 5 Products by Quantity
SELECT 
    p.product_name,
    SUM(f.quantity) AS total_quantity
FROM fact_sales f
JOIN dim_products p
ON f.product_id = p.product_id
GROUP BY p.product_name
ORDER BY total_quantity DESC
LIMIT 5;
