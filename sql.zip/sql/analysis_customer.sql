
-- Orders per Customer
SELECT 
    c.customer_id,
    c.customer_name,
    COUNT(f.sales_id) AS total_orders
FROM fact_sales f
JOIN dim_customers c
ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY total_orders DESC;

-- Total Spend per Customer
SELECT 
    c.customer_id,
    c.customer_name,
    SUM(f.total_amount) AS total_spent
FROM fact_sales f
JOIN dim_customers c
ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY total_spent DESC;

-- Top 10 High-Value Customers
SELECT 
    c.customer_id,
    c.customer_name,
    SUM(f.total_amount) AS lifetime_value
FROM fact_sales f
JOIN dim_customers c
ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.customer_name
ORDER BY lifetime_value DESC
LIMIT 10;
