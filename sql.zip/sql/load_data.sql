USE retail_project;

LOAD DATA LOCAL INFILE 'data/raw/dim_customers.csv'
INTO TABLE dim_customers
FIELDS TERMINATED BY ','
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE 'data/raw/dim_products.csv'
INTO TABLE dim_products
FIELDS TERMINATED BY ','
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE 'data/raw/fact_sales.csv'
INTO TABLE fact_sales
FIELDS TERMINATED BY ','
IGNORE 1 ROWS;
