WITH ref_date AS (
    SELECT MAX(sales_date) AS max_date FROM fact_sales
),
rfm_base AS (
    SELECT
        c.customer_id,
        julianday(r.max_date) - julianday(MAX(f.sales_date)) AS recency,
        COUNT(f.sales_id) AS frequency,
        SUM(f.total_amount) AS monetary
    FROM fact_sales f
    JOIN dim_customers c
    ON f.customer_id = c.customer_id
    CROSS JOIN ref_date r
    GROUP BY c.customer_id
)
SELECT
    customer_id,
    recency,
    frequency,
    monetary,
    CASE
        WHEN recency <= 30 AND frequency >= 5 AND monetary >= 10000 THEN 'Champions'
        WHEN recency <= 60 AND frequency >= 3 THEN 'Loyal Customers'
        WHEN recency > 90 AND frequency >= 3 THEN 'At Risk'
        WHEN recency > 120 THEN 'Lost'
        ELSE 'Regular'
    END AS customer_segment
FROM rfm_base
ORDER BY monetary DESC;


-- customer count per segment
SELECT customer_segment, COUNT(*) AS customer_count
FROM (
    WITH ref_date AS (
    SELECT MAX(sales_date) AS max_date 
    FROM fact_sales
),
rfm_base AS (
    SELECT
        c.customer_id,
        julianday(r.max_date) - julianday(MAX(f.sales_date)) AS recency,
        COUNT(f.sales_id) AS frequency,
        SUM(f.total_amount) AS monetary
    FROM fact_sales f
    JOIN dim_customers c
        ON f.customer_id = c.customer_id
    CROSS JOIN ref_date r
    GROUP BY c.customer_id
)
SELECT
    customer_id,
    recency,
    frequency,
    monetary,
    CASE
        WHEN recency <= 30 AND frequency >= 5 AND monetary >= 10000 THEN 'Champions'
        WHEN recency <= 60 AND frequency >= 3 THEN 'Loyal Customers'
        WHEN recency > 90 AND frequency >= 3 THEN 'At Risk'
        WHEN recency > 120 THEN 'Lost'
        ELSE 'Regular'
    END AS customer_segment
FROM rfm_base

)
GROUP BY customer_segment;

-- revenue per segment
SELECT
    customer_segment,
    SUM(monetary) AS segment_revenue
FROM (
     WITH ref_date AS (
    SELECT MAX(sales_date) AS max_date 
    FROM fact_sales
),
rfm_base AS (
    SELECT
        c.customer_id,
        julianday(r.max_date) - julianday(MAX(f.sales_date)) AS recency,
        COUNT(f.sales_id) AS frequency,
        SUM(f.total_amount) AS monetary
    FROM fact_sales f
    JOIN dim_customers c
        ON f.customer_id = c.customer_id
    CROSS JOIN ref_date r
    GROUP BY c.customer_id
)
SELECT
    customer_id,
    recency,
    frequency,
    monetary,
    CASE
        WHEN recency <= 30 AND frequency >= 5 AND monetary >= 10000 THEN 'Champions'
        WHEN recency <= 60 AND frequency >= 3 THEN 'Loyal Customers'
        WHEN recency > 90 AND frequency >= 3 THEN 'At Risk'
        WHEN recency > 120 THEN 'Lost'
        ELSE 'Regular'
    END AS customer_segment
FROM rfm_base
)
GROUP BY customer_segment
ORDER BY segment_revenue DESC;
