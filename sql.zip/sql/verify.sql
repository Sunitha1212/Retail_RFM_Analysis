SELECT COUNT(*) FROM dim_customers;
SELECT COUNT(*) FROM dim_products;
SELECT COUNT(*) FROM fact_sales;
SELECT * FROM customer_sales_view;
SELECT COUNT(sales_date) FROM fact_sales;
SELECT DISTINCT product_id FROM fact_sales LIMIT 10;
SELECT DISTINCT product_id FROM dim_products LIMIT 10;
