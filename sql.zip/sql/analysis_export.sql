/* =========================
   DASHBOARD DATA PREP
   ========================= */

-- Monthly Revenue Trend
SELECT
    substr(sales_date, 1, 7) AS month,
    SUM(total_amount) AS monthly_revenue
FROM fact_sales
GROUP BY month
ORDER BY month;

-- Region-wise Revenue
SELECT
    c.region,
    SUM(f.total_amount) AS region_revenue
FROM fact_sales f
JOIN dim_customers c
ON f.customer_id = c.customer_id
GROUP BY c.region;


/* =========================
   CSV EXPORT QUERIES
   ========================= */

-- Export Customer Summary
SELECT
    c.customer_id,
    c.customer_name,
    COUNT(f.sales_id) AS total_orders,
    SUM(f.total_amount) AS total_spent
FROM fact_sales f
JOIN dim_customers c
ON f.customer_id = c.customer_id
GROUP BY c.customer_id, c.customer_name;

-- Export Product Summary
SELECT
    p.product_name,
    p.category,
    SUM(f.quantity) AS units_sold,
    SUM(f.total_amount) AS revenue
FROM fact_sales f
JOIN dim_products p
ON f.product_id = p.product_id
GROUP BY p.product_name, p.category;
